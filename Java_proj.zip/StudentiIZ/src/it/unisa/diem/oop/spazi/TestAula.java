package it.unisa.diem.oop.spazi;

public class TestAula {
    public static void main(String[] args) {
        
    }    
}
