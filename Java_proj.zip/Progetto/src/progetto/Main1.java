package progetto;

public class Main1 {
    public static void main(String[] args) {
        System.out.println("1111");
    }    
}
