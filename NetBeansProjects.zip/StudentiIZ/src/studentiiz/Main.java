package studentiiz;
import it.unisa.diem.oop.persone.*;

public class Main {
    public static void main(String[] args) {
        Persona p0 = new Persona("savasio","sava","IFBUIBi43534");
        
        //PersonaUnisa p1 = new PersonaUnisa();
        
        Studente s1 = new Studente("Andrea", "Savastano", "SVSNDR04B128Q", "0612707904", 29F);
        System.out.println("Nome: "+s1.getNome());
        System.out.println("Cognome: "+s1.getCognome());
        System.out.println("Codice Fiscale: "+s1.getCodiceFiscale());
        System.out.println("Matricola: "+s1.getMatricola());
        System.out.println("Voto medio: "+s1.getVotoMedio());
        
        Persona p = new Persona("And", "Sav", "asdasda");
        Studente s = new Studente();
        System.out.println(s.toString());
        System.out.println(p); // in seguito all'override si usa quello definito da noi
        /*
        non stampiano un vero e proprio riferimento, bensì viene richiamato il metodo
        toString()
        La super classe di tutte le classi è Object che contiene dei metodi e attributi che
        vengono ereditate da tutte le classi che andiamo a definire -> tutte le classi
        che definiamo estendono object, QUINDI possiamo usare toString()
        ctrl+toString() -> 
        Returns a string representation of the object. In general, the toStringmethod 
        returns a string that "textually represents" this object. The result should be a 
        concise but informative representation that is easy for a person to read. It is 
        recommended that all subclasses override this method.
        The toStringmethod for class Object returns a string consisting of the name of the class of which the object is an instance, the at-sign character `@, and the unsigned hexadecimal representation of the hash code of the object. In other words, this method returns a string equal to the value of:
        
        La rappresentazione it.unisa.diem.oop.persone.Studente@6d06d69c
        RIDEFINIZIONE DI UN METODO -> una delle caratteristiche di ereditarietà, non è solo
        ereditare ma anche ridefinire dando una nuova implementazione del metodo:
        nella classe persona dobbiamo includere la STESSA METODO: stesso tipo di ritorno
        e parametri
        Quando faccio una ridefinizione -> quel metodo VA ANNOTATO: si chiama @Override
        
        SI DECIDE di usare toString() della CLASSE PIU' BASSA DELLA GERARCHIA DI EREDITARIETà
        QUINDI System.out.println(s.toString()); PRENDE il toString(); della classe Studente
        che è quella biù bassa gerarchicamente
        
        L'override naturalmente si può fare per tutit i metodi, anche per getNome ma non ha
        senso quindi VOGLIO IMPEDIRE CHE VENGA FATTO l'override usando FINAL:
        final per i metodi stabilisce che una sotto classe NON può fare
        override: public final String getNome(){
        @Override
    public String getNome(){
        return "Luca";
    } in persona unisa
        
        final preclude override ma non overload
        
        posso fare anche per una classe classe -> le sue sottoclassi non possono ereditareù
        public final class Persona {
        
        
        
        relazione ereditarietà: "is"
        relazione composizione: "has"
        */
        
        /*
        upcast voglio assegnare l'stanza del figlio a un riferimento del padre
        
        downcast NON si può fare
        */
        Persona s2 = new Studente();
        /*upcast sto declassando il riferimento  s2 -> posso usare solo i 3 metodi 
        il riferimento di tipo persona mi dà un margine ristretto, non sto eliminando
        l'oggetto studente, il meccanismo è sempre possibile */
        
        //Studente s3 = p;
        /*
        downcast NON possibile perchè ci sono dei metodi che non ha p, ossia getMatricola,
        e getVotoMedio.
        Questo errore potrebbe essere risolto: forzarlo (Studente)
        */
        //Studente s3 = (Studente) p;
        
        /*
        persona ridefinisce toString
        personaUnisa ridefinisce toString
        Studente ridefinisce toString
        Il metodo scelto è quello di Studente anche se è stato declassato a persona
        Persona s2 = new Studente();
        s2.toString(); la toString di Studente pur avendo il riferimento s2 come persona
        perchè la new crea prima l'oggetto studente e poi abbiamo DECLASSATO IL 
        RIFERIMENTO, quindi il metodo toString() è già stato definito
        la scelta è fatta durante l'esecuzione proprio a causa dell'ereditarietà
        MECCANISMO IMPORTANTISSIMO 
        */
        /*
        Vantaggio:
        Se fisso un array di persone posso far entrare qualsiasi persona in Aula
        però per usare i metodi di studente anche se ha il riferimento declassato a 
        persona, devo fare il downcast, MA PRIMA DEVO VERIFICARE CHE APPARTIENE
        EFFETTIVAMENTE A QUELLA CLASSE
        :
        Voglio accedere alla persona nell'aula che è uno studente
        */
        
        //Persona s2 = new Studente();
        if(s2 instanceof Studente){
            Studente s3 = (Studente) s2;
            System.out.println(s3.getVotoMedio());
        }
        /* oppure: */
        if(s2.getClass() == Studente.class){
            Studente s3 = (Studente) s2;
            System.out.println(s3.getVotoMedio());
        }
        /*
        s2.getClass() restituisce un oggetto classe che identifica la classe di s2 Studente
        è utile quando voglio confrontare due oggetti, anche se si può usare instanceof
        
        
        PersonaUnisa rappresenta unentità concreta ?? una persona che sia una personaUnisa che ha solo
        la matricola e non è niente, non ha senso ISTANZIARLA
        Quindi esistono delle classi che progettiamo solo con scopo utilitaristico
        ossia le CLASSI ASTRATTE CHE NON POSSONO ESSERE ISTANZIATE 
        PersonaUnisa p1 = new PersonaUnisa(); l'unica cosa che precludde NO!
        nel dominio applicativo NON ESISTE QUESTA CLASSE quindi è astratta, ma serve comunque per specializzare 
        studenti, docenti,...
        
        
        
        tipo wrapper per convertire i tipi primitivi in classi, come int -> integer
        il vantaggio è che avremo i vari metodi
        */        
        
        
    }    
}
