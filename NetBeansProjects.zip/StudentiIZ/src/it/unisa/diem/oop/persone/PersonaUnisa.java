package it.unisa.diem.oop.persone;

public abstract class PersonaUnisa extends Persona {
    /*non voglio riscrivere gli attributi quindi aggiungo solo matricola*/
    private String matricola;
    /*key word: extends per dire che 
    personaunisa è una specializzazione / estensione di persona
    quando definisco un'estensione devo definire lo stato (nome, cognome, codicefiscale) ->
    ho bisogno di usare un costruttore per inizializzare gli attributi della classe madre persona*/
    
    public PersonaUnisa() {
        this("no name", "no surname", "no codice fiscale", "no matricola");
    } 
    
    public PersonaUnisa(String nome, String cognome, String codiceFiscale, String matricola) {
        /*devo gestire i parametri di persona come faccio ?*/
        // come quando uso this per riferirmi a un altro costruttore
        super(nome, cognome, codiceFiscale);
        /*è la prima cosa: invocare il costruttore della super classe / classe madre
        super = istanzioare l'oggeto della super classe
        posso accedere solo agli attributi PUBLIC e non PRIVATE*/
        this.matricola = matricola;
    }    
    
    /*il senso di questo metodo 
    le classi
    Una classe astratta può avere 1 o più metodi astratti e deve essere ridefinito dalle sottoclassi!
    OBBLIGO LE SOTTOCLASSI A RIDEFINIRE questo metodo
    QUESTO LO DOBBIAMO METTERE PERCHè IN QUESTO MODO OBBLIGHIAMO ALLE CLASSI DERIVATE (CONCRETE) A METTERLO
    E INOLTRE devono avere lo stesso nome, invece non mettere public abstract String getRuolo(); significa
    lasciare un'opzione alla sottoclasse di chiamarlo o meno e con che nome*/
    public abstract String getRuolo();
    
    public String getMatricola(){
        return this.matricola;
    }        
    
    @Override
    public String toString(){
        return super.toString()+" "+this.matricola;
    }
}
